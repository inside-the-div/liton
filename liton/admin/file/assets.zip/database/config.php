<?php  

	define('server','localhost');
	define('user_name','nasineun_blog');
	define('password','(Dubyw4Io%rd');
	define('database_name','nasineun_my_blog');


?>
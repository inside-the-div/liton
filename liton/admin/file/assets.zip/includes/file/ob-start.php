<?php


// start object  
ob_start();

// database 
include('database/database.php');
// session
include('session/session.php');
// handler
include('handler/handler.php');


?>
  <!-- Favicons-->
  <link rel="shortcut icon" href="img\favicon.ico" type="image/x-icon">
  <link rel="apple-touch-icon" type="image/x-icon" href="img\apple-touch-icon-57x57-precomposed.png">
  <link rel="apple-touch-icon" type="image/x-icon" sizes="72x72" href="img\apple-touch-icon-72x72-precomposed.png">
  <link rel="apple-touch-icon" type="image/x-icon" sizes="114x114" href="img\apple-touch-icon-114x114-precomposed.png">
  <link rel="apple-touch-icon" type="image/x-icon" sizes="144x144" href="img\apple-touch-icon-144x144-precomposed.png">
	
  <!-- Bootstrap core CSS-->
  <link href="assets\css\bootstrap.min.css" rel="stylesheet">
  <!-- Main styles -->
  <link href="assets\css\admin.css" rel="stylesheet">
  <!-- Icon fonts-->
  <link href="assets\font-awesome\css\font-awesome.min.css" rel="stylesheet" type="text/css">

    <!-- Plugin styles -->
  <link href="assets\css\dataTables.bootstrap4.css" rel="stylesheet">
  <!-- WYSIWYG Editor -->
  <link rel="stylesheet" href="assets\summer-note\summernote-bs4.css">
  <!-- Your custom styles -->
  <link href="assets\css\custom.css" rel="stylesheet">
	
</head>
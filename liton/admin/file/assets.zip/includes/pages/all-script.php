    <!-- Bootstrap core JavaScript-->
    <script src="assets\js\jquery.min.js"></script>
    <script src="assets\js\bootstrap.bundle.min.js"></script>

    <script src="assets\js\jquery.dataTables.js"></script>
    <script src="assets\js\dataTables.bootstrap4.js"></script>
    <script src="assets\js\admin-datatables.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="assets\js\admin.js"></script>
    <script src="assets\js\function.js"></script>


<?php 



	include('session/session.php');
	$session->logout('index.php');



?>